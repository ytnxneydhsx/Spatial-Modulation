
function bpsk_code=bpsk(code_longth)
bpsk_code = randi([0, 1], 1, code_longth); 
end